from game_classes import bullet
from game_classes import player_class
from game_classes import enemy
from game_classes import rectt
from pygame.sprite import Group
import pygame
pygame.init()
global scx
global scy
scx = 1000
scy = 500
playerplacement = [0,0]


dis = pygame.display.set_mode((scx,scy))

ti = pygame.time.Clock()
speed = [2,2,5]
theguy1 = player_class(20,20,scx//2,scy//2 - 100,speed)
theboys = Group()
obs = Group()
ladder = Group()
projectiles = Group()
col1 = rectt(800,20,scx//2,400)
col2 = rectt(400,20,scx//2+20,300)
col3 = rectt(60,100,scx//2,400)
theboys.add(theguy1)
obs.add(col1,col2,col3) 
therun = True
enem1 = enemy(scx//2+300,scy//2-30)
enem2 = enemy(scx//2-300,scy//2-30)
enem3 = enemy(scx//2,scy//2-60)
enemies = Group(enem1,enem2,enem3)
target_lock = 0
lock_potential = [enem1,enem2,enem3]
while therun:
    for each in pygame.event.get():
        if each.type == pygame.QUIT:
            quit()
            exit()
        if each.type == pygame.KEYDOWN:
            if each.key == pygame.K_i:
                if target_lock < len(lock_potential)-1:
                    target_lock += 1
                elif not lock_potential:
                    print('hhhh')
                else:
                    target_lock = 0
            if each.key == pygame.K_k and lock_potential:
                nebull = bullet(5,[lock_potential[target_lock].rect.centerx,lock_potential[target_lock].rect.centery],theguy1.rect.centerx,theguy1.rect.centery)
                projectiles.add(nebull)
        if each.type == pygame.MOUSEBUTTONDOWN and lock_potential:
            nebull = bullet(5,[lock_potential[target_lock].rect.centerx,lock_potential[target_lock].rect.centery],theguy1.rect.centerx,theguy1.rect.centery)
            projectiles.add(nebull)
    dis.fill('White')
    obs.update()
    pygame.sprite.groupcollide(projectiles,obs,True,False)
    obs.draw(dis)
    theboys.draw(dis)
    projectiles.update()
    projectiles.draw(dis)
    theguy1.move(obs)
    theguy1.collison(obs)
    enemies.update()
    enemies.draw(dis)
    ti.tick(120)
    pygame.display.update()