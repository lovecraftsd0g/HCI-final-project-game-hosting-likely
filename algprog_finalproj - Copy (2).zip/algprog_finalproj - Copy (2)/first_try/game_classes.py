from typing import Any
import pygame
from pygame.sprite import Group
import random
import copy
import math
import time
global scx
global scy
scx = 1000
scy = 500
listofen = []
class bullet(pygame.sprite.Sprite):
    def __init__(self,speed,x,y,image):
        pygame.sprite.Sprite.__init__(self)
        self.speed = speed
        self.image = pygame.image.load(image)
        self.rect = self.image.get_rect(center=(x,y))
    def update(self,col):
        self.rect.x += self.speed
        if pygame.sprite.spritecollide(self,col,False):
            self.kill()


class player_class(pygame.sprite.Sprite):
    def __init__(self,x,y,xpo,ypo,speed):
        pygame.sprite.Sprite.__init__(self)
        self.x = x
        self.y = y
        self.speed = speed
        self.image = pygame.Surface((x,y))
        self.rect = self.image.get_rect(center = (xpo,ypo))
        self.image.fill('Black')
        self.tick = 0
        self.jump_tick_max = 30
        self.jump_amount = 1
        self.jump_tick = self.jump_tick_max 
        self.jump_state = False
        self.lasttpneg = 0
        self.lasttppos = 0

    def move(self,col):
        lel = pygame.sprite.spritecollide(self,col,dokill=False)
        keys = pygame.key.get_pressed()
        speed = 0
        

        if self.jump_state:
            self.jump()

        if keys[pygame.K_d]:
            speed = self.speed[0]
        elif keys[pygame.K_a]:
            speed = -self.speed[1] 

                
        self.rect.x += speed
        self.rect.y += self.speed[2]
                    
        


    def collison(self,col1):
        "this function is constanly detecting the collision of other collison objects and will store each object in this for loop"
        "function to calculate and determine the speed list"
        
        #ground_collision = pygame.sprite.spritecollide(self,col2,dokill=False)
        k = pygame.key.get_pressed()
        

        collision_check = pygame.sprite.spritecollide(self,col1,dokill=False)

        if collision_check:
            for collided in collision_check:
                if collided.rect.top > self.rect.bottom-2  and self.rect.centerx<collided.rect.right and self.rect.centerx > collided.rect.left:
                    self.speed[2] = 0
                    if k[pygame.K_w] and collided.rect.top > self.rect.bottom -10:
                        self.jump_state = True
                

                if (abs(collided.rect.right - self.rect.left)  < 5 and collided.rect.top < self.rect.bottom) or abs(0-self.rect.left) <= 0:
                    self.speed[1] = 0
                else:
                    self.speed[1] = 2

                if (abs(collided.rect.left - self.rect.right)  < 5 and collided.rect.top < self.rect.bottom) or abs(0-self.rect.right) <= 0:
                    self.speed[0] = 0
                else:
                    self.speed[0] = 2
        else:
            if abs(0-self.rect.left) <= 0:
                self.speed[1] = 0
            else:
                self.speed[1] = 2
            if abs(scx-self.rect.right) <= 0:
                self.speed[0] = 0
            else:
                self.speed[0] = 2
            self.speed[2] = 2
    def jump(self):
        if self.jump_amount > 0:
            if self.jump_tick > 0:
                self.speed[2] = -2
                self.jump_tick -= 1
            elif self.jump_tick <= 0:
                self.jump_state = False
                self.jump_tick = self.jump_tick_max
                self.jump_amount = 1

        
    


class bullet(pygame.sprite.Sprite):
    def __init__(self,speed,target,x,y):
        pygame.sprite.Sprite.__init__(self)
        self.speed = speed
        self.image = pygame.Surface((10,10))
        self.x = x
        self.y = y
        self.rect = self.image.get_rect(center = (x,y))
        angle = math.atan2(target[1]-self.rect.centery,target[0]-self.rect.centerx)
        self.dx = math.cos(angle)*self.speed
        self.dy = math.sin(angle)*self.speed
    def update(self) :
        self.image.fill('Black')
        self.x += self.dx
        self.y += self.dy
        self.rect.centerx = self.x
        self.rect.centery = self.y


class enemy(pygame.sprite.Sprite):
    def __init__(self,x,y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((40,40))
        self.rect = self.image.get_rect(center=(x,y))
    def update(self):
        self.image.fill('Yellow')

class rectt(pygame.sprite.Sprite):
    def __init__(self,x,y,xpo,ypo):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((x,y))
        self.rect = self.image.get_rect(center = (xpo,ypo))
        self.image.fill('Blue')